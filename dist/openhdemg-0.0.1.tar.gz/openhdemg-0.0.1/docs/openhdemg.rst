Open_HD-EMG package
"""""""""""""""""""

Library
-------

.. toctree::
   :maxdepth: 4

   library

Graphical User Interface
------------------------

.. automodule:: openhdemg_gui
   :members:
   :undoc-members:
   :show-inheritance:

   