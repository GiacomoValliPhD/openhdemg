Documentation
=============
Here you can find the code documentation of Open_HD-EMG.

.. toctree::
   :maxdepth: 1

   openhdemg